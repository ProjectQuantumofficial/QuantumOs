var searchData=
[
  ['phraseextract',['PhraseExtract',['../classopencc_1_1_phrase_extract.html',1,'opencc']]],
  ['ptrdictentry',['PtrDictEntry',['../classopencc_1_1_ptr_dict_entry.html',1,'opencc']]]
];
