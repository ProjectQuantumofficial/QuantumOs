var searchData=
[
  ['invalidformat',['InvalidFormat',['../classopencc_1_1_invalid_format.html',1,'opencc']]],
  ['invalidtextdictionary',['InvalidTextDictionary',['../classopencc_1_1_invalid_text_dictionary.html',1,'opencc']]],
  ['invalidutf8',['InvalidUTF8',['../classopencc_1_1_invalid_u_t_f8.html',1,'opencc']]],
  ['islineendingorfileending',['IsLineEndingOrFileEnding',['../classopencc_1_1_u_t_f8_util.html#a008b85311545f43a7a3c14e304004266',1,'opencc::UTF8Util']]],
  ['isnull',['IsNull',['../classopencc_1_1_optional.html#a1e0bf8b941446d82796cfa0e0aa413de',1,'opencc::Optional']]],
  ['iterator',['iterator',['../classopencc_1_1_segments_1_1iterator.html',1,'opencc::Segments']]]
];
