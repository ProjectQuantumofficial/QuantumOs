var searchData=
[
  ['convert',['Convert',['../classopencc_1_1_simple_converter.html#a0042dba7fe92bee2cadb4d7a8cbec929',1,'opencc::SimpleConverter::Convert(const std::string &amp;input) const'],['../classopencc_1_1_simple_converter.html#a3bc95485e6b8c5bca6b728f557efd98a',1,'opencc::SimpleConverter::Convert(const char *input) const'],['../classopencc_1_1_simple_converter.html#a63baff1214203c8835105b5167daba43',1,'opencc::SimpleConverter::Convert(const char *input, size_t length) const'],['../classopencc_1_1_simple_converter.html#ac9eb53d7dbecf687e0d43eaaf9bf2bd1',1,'opencc::SimpleConverter::Convert(const char *input, char *output) const'],['../classopencc_1_1_simple_converter.html#a63f5dbba323443bd42772d4c5c77b313',1,'opencc::SimpleConverter::Convert(const char *input, size_t length, char *output) const']]],
  ['convertdictionary',['ConvertDictionary',['../group__opencc__cpp__api.html#gab218db32cfc24e275b00e7dbd26c00c3',1,'opencc']]]
];
