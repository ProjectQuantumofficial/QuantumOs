var searchData=
[
  ['join',['Join',['../classopencc_1_1_u_t_f8_util.html#ac2c522f4bc20ea7b08a921fb8380c9e7',1,'opencc::UTF8Util::Join(const vector&lt; string &gt; &amp;strings, const string &amp;separator)'],['../classopencc_1_1_u_t_f8_util.html#aec5b28619d5a84d13abcc193f6f2bcc4',1,'opencc::UTF8Util::Join(const vector&lt; string &gt; &amp;strings)']]]
];
